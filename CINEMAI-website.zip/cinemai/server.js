require("dotenv").config();
const express = require("express");
const path = require("path");
const { fal } = require("@fal-ai/client");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const MODEL = "fal-ai/kling-video/v3/pro/text-to-video";

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.FAL_KEY) });
});

app.post("/api/generate", async (req, res) => {
  try {
    if (!process.env.FAL_KEY) {
      return res.status(503).json({
        error: "Video generation is not connected yet. Add your private FAL_KEY to the hosting environment variables."
      });
    }

    const { prompt, duration = "5", aspect_ratio = "9:16", generate_audio = true } = req.body || {};
    if (typeof prompt !== "string" || prompt.trim().length < 8) {
      return res.status(400).json({ error: "Please describe your video in at least 8 characters." });
    }
    if (prompt.length > 2400) return res.status(400).json({ error: "Prompt is too long. Keep it under 2,400 characters." });
    if (!["5", "10", "15"].includes(String(duration))) {
      return res.status(400).json({ error: "Choose a supported duration: 5, 10 or 15 seconds." });
    }
    if (!["16:9", "9:16", "1:1"].includes(aspect_ratio)) {
      return res.status(400).json({ error: "Choose 16:9, 9:16 or 1:1." });
    }

    fal.config({ credentials: process.env.FAL_KEY });
    const result = await fal.subscribe(MODEL, {
      input: {
        prompt: prompt.trim(),
        duration: String(duration),
        aspect_ratio,
        generate_audio: Boolean(generate_audio),
        enable_safety_checker: true
      },
      logs: false
    });

    const videoUrl = result?.data?.video?.url;
    if (!videoUrl) {
      console.error("Unexpected provider response:", result?.data);
      return res.status(502).json({ error: "The video provider did not return a video. Please try again." });
    }
    res.json({ video: { url: videoUrl }, requestId: result.requestId || null });
  } catch (err) {
    console.error("Generation error:", err?.message || err);
    const msg = err?.message || "Video generation failed.";
    res.status(502).json({ error: msg.slice(0, 400) });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`CINEMAI running on port ${port}`));