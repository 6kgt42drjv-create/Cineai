# CINEMAI

A mobile-friendly AI video studio. The browser UI is public and requires no user account. The server keeps the provider API key private and submits generation requests to Kling Video through fal.ai.

## Important
- Video generation is not free by default. The provider charges according to its current pricing and account limits.
- You need a provider account and API key for the server. Visitors do not need accounts on CINEMAI.
- Never expose `FAL_KEY` in browser JavaScript or commit a real `.env` file.
- Generation is subject to the provider's safety rules and availability.

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and set `FAL_KEY`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## Deploy online with Render
1. Create a private GitHub repository and upload these project files.
2. In Render, create a new **Web Service** from that repository.
3. Use build command `npm install` and start command `npm start`.
4. Add environment variable `FAL_KEY` in the Render service settings. Do not add it to source code.
5. Deploy. Render will provide a public HTTPS URL.

The included `render.yaml` describes the service. Hosting may have a cost or sleep/usage limits depending on the current plan. Review the host's current pricing before deploying.

## Provider model
The server uses `fal-ai/kling-video/v3/pro/text-to-video`. If the provider changes its endpoint or schema, update `MODEL` and the `input` object in `server.js` to match its current API documentation.

## API
`POST /api/generate`
```json
{
  "prompt": "A cinematic shot of ...",
  "duration": "5",
  "aspect_ratio": "9:16",
  "generate_audio": true
}
```
Returns `{ "video": { "url": "https://..." }, "requestId": "..." }` on success.
